//wait for the DOM elements to load before executing
jQuery(document).ready(function() {
  
function initMap() {
  var map = new google.maps.Map(document.getElementById('map'), {


});


