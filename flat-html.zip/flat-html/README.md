echo "# Adrienne-FEWD-Final-Project" >> README.md

!
###Adrienne FEWD Final Project


By week 7, you should have submitted psuedo code and a draft of the HTML/CSS for your application.  This week, you'll focus on drafting the JavaScript and jQuery you'll need for your application. 
